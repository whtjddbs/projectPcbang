function checkWrite(){
	if(document.writeForm.name.value=="") 
		alert("이름을 입력하세요");
	else if(document.writeForm.id.value=="") 
		alert("아이디를 입력하세요");
	else if(document.writeForm.pwd.value=="") 
		alert("비밀번호를 입력하세요");
	else if(document.writeForm.pwd.value!=document.writeForm.repwd.value) 
		alert("비밀번호가 맞지않습니다");
	else if(document.writeForm.checkedId.value=="")
		alert("중복체크하세요");
	else if(document.writeForm.checkedId.value!=document.writeForm.id.value)
		alert("중복체크하세요");
	else
		document.writeForm.submit();	
} 

function checkId(){
	var sId=document.writeForm.id.value;
	if(sId=="")
		alert("먼저 아이디를 입력하세요");
	else
		window.open("checkId.jsp?id="+sId,"","width=300 height=100 location=yes");
}

function checkLogin() {
	if(document.loginForm.id.value == "")
		alert("아이디를 입력하세요");
	else if (document.loginForm.pwd.value == "")
		alert("비밀번호를 입력하세요");
	else
		document.loginForm.submit();
}

function checkModify() {
	if(document.modifyForm.name.value=="") 
		alert("이름을 입력하세요");
	else if(document.modifyForm.pwd.value=="") 
		alert("비밀번호를 입력하세요");
	else if(document.modifyForm.pwd.value!=document.modifyForm.repwd.value) 
		alert("비밀번호가 맞지않습니다");
	else
		document.modifyForm.submit();
}

function checkIdClose(id) {
	//아이디 전달
	opener.writeForm.id.value=id;
	opener.writeForm.checkedId.value=id;
	//창닫기
	window.close();
	//비밀번호에 포커스 맞추기
	opener.writeForm.pwd.focus();
}

function checkPost(){
	window.open("checkPost.jsp","","width=600 height=400 scrollbars=yes");
}

function checkBoardWrite(){
	if(document.boardWriteForm.subject.value="")
		alert("제목을 입력하세요");
	else
		document.boardWriteForm.submit();
}

function checkPostClose(zipcode, address){
	opener.writeForm.zipcode.value=zipcode;
	opener.writeForm.addr1.value=address;
	
	window.close();
	
	opener.writeForm.addr2.focus();
}











 