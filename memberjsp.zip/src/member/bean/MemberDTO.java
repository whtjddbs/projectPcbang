package member.bean;

import lombok.Data;

@Data
public class MemberDTO {
	String name;
	String id;
	String pwd;
	String gender;
	String email1;
	String email2;
	String tel1;
	String tel2;
	String tel3;
	String zipcode;
	String addr1;
	String addr2;
	
}
