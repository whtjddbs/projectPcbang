package member.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import member.bean.MemberDTO;
import member.bean.PostDTO;

public class MemberDAO {

	private String driver = "oracle.jdbc.driver.OracleDriver";
	private String url = "jdbc:oracle:thin:@localhost:1521:xe";
	private String username = "java";
	private String password = "itbank";
	private Connection conn;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	private static MemberDAO instance;
	
	public static MemberDAO getInstance() {
		if(instance==null) {
			synchronized(MemberDAO.class) {
				instance=new MemberDAO();
			}
		}
		return instance;
	}
	
	public MemberDAO() {
		try {
			Class.forName(driver); 
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} 
	}
	
	public void getConnection() {
		try {
			conn=DriverManager.getConnection(url, username, password);
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	//DB�� DTO������
	public int write(MemberDTO memberDTO) {
		int su=0;
		getConnection();
		String sql="insert into member values(?,?,?,?,?,?,?,?,?,?,?,?,sysdate)";
		
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1,memberDTO.getName());
			pstmt.setString(2,memberDTO.getId());
			pstmt.setString(3,memberDTO.getPwd());
			pstmt.setString(4,memberDTO.getGender());
			pstmt.setString(5,memberDTO.getEmail1());
			pstmt.setString(6,memberDTO.getEmail2());
			pstmt.setString(7,memberDTO.getTel1());
			pstmt.setString(8,memberDTO.getTel2());
			pstmt.setString(9,memberDTO.getTel3());
			pstmt.setString(10,memberDTO.getZipcode());
			pstmt.setString(11,memberDTO.getAddr1());
			pstmt.setString(12,memberDTO.getAddr2());
			
			su=pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(pstmt!=null) pstmt.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return su;
	}
	
	public String login(String id,String pwd) {
		String name=null;
		getConnection();
		String sql="select * from member where id=? and pwd=?";
		
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setString(2, pwd);
			
			rs=pstmt.executeQuery();
			if(rs.next()) name=rs.getString("name");
			
		} catch (SQLException e) {
			e.printStackTrace();
		}  finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null) pstmt.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return name;
	}
	
	public MemberDTO getMember(String id) {
		getConnection();
		String sql="select * from member where id=?";
		MemberDTO memberDTO=null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs=pstmt.executeQuery();
			
			if(rs.next()) {
				memberDTO=new MemberDTO();
				
				memberDTO.setName(rs.getString("name"));
				memberDTO.setId(rs.getString("id"));
				memberDTO.setPwd(rs.getString("pwd"));
				memberDTO.setGender(rs.getString("gender"));
				memberDTO.setEmail1(rs.getString("email1"));
				memberDTO.setEmail2(rs.getString("email2"));
				memberDTO.setTel1(rs.getString("tel1"));
				memberDTO.setTel2(rs.getString("tel2"));
				memberDTO.setTel3(rs.getString("tel3"));
				memberDTO.setZipcode(rs.getString("zipcode"));
				memberDTO.setAddr1(rs.getString("addr1"));
				memberDTO.setAddr2(rs.getString("addr2"));
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null) pstmt.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return memberDTO;
	}

	public int update(MemberDTO memberDTO) {
		int su=0;
		getConnection();
		String sql="update member set name=?, email1=?, email2=?, gender=?,"
				+ " tel1=?, tel2=?, tel3=?, zipcode=?, addr1=?, addr2=?,logtime=sysdate where id= ?";
		
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, memberDTO.getName());
			pstmt.setString(2, memberDTO.getEmail1());
			pstmt.setString(3, memberDTO.getEmail2());
			pstmt.setString(4, memberDTO.getGender());
			pstmt.setString(5, memberDTO.getTel1());
			pstmt.setString(6, memberDTO.getTel2());
			pstmt.setString(7, memberDTO.getTel3());
			pstmt.setString(8, memberDTO.getZipcode());
			pstmt.setString(9, memberDTO.getAddr1());
			pstmt.setString(10, memberDTO.getAddr2());
			pstmt.setString(11, memberDTO.getId());
			
			su=pstmt.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}  finally {
			try {
				if(pstmt!=null) pstmt.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}return su;
	}
	
	public void boardWrite(String subject, String content) {
		int su=0;
		getConnection();
		String sql="insert into board values(seq_board.nextval,?,?,?,?,?,?,?,?,?,?,?,sysdate)";
		
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1,"");
			pstmt.setString(2,"");
			pstmt.setString(3,"");
			pstmt.setString(4,subject);
			pstmt.setString(5,content);
			pstmt.setString(6,"");
			pstmt.setString(7,"");
			pstmt.setString(8,"");
			pstmt.setString(9,"");
			pstmt.setString(10,"");
			pstmt.setString(11,"");
			
			su=pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(pstmt!=null) pstmt.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public ArrayList<PostDTO> getZipcodeList(String sido, String sigungu, String roadname) {
		ArrayList<PostDTO> list=new ArrayList<PostDTO>();
		getConnection();
		String sql="select * from newzipcode where sido like?"
				+ "and sigungu like ?"
				+ "and roadname like ? ";
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, "%"+sido+"%");
			pstmt.setString(2, "%"+sigungu+"%");
			pstmt.setString(3, "%"+roadname+"%");
			
			rs=pstmt.executeQuery();
			
			while(rs.next()) {
				PostDTO postDTO=new PostDTO();
				postDTO.setZipcode(rs.getString("zipcode"));
				postDTO.setSido(rs.getString("sido"));
				postDTO.setSigungu(rs.getString("sigungu")==null ? "":rs.getString("sigungu"));
				postDTO.setYubmyundong(rs.getString("yubmyundong"));
				postDTO.setRi(rs.getString("ri")==null ? "" : rs.getString("ri"));
				postDTO.setRoadname(rs.getString("roadname"));
				postDTO.setBuildingname(rs.getString("buildingname")==null ? "":rs.getString("buildingname"));
				
				list.add(postDTO);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			list=null;
		} finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null) pstmt.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}
	
}









