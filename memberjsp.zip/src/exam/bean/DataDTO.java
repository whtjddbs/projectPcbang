package exam.bean;

import lombok.Data;

@Data
public class DataDTO {
	private int x;
	private int y;
	
}
